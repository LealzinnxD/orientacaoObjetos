public class Principal {
    
    public static void main(String[] args) {
        
      Metodos jv = new Metodos();
      MetodoRetorno ll =new MetodoRetorno();
      MetodoRetornoParametro carro = new MetodoRetornoParametro();

      //ll.calcularNotas();

      //jv.leal();

      carro.turboCarro(30);
      
    }
}
