import java.util.Scanner;

public class Pessoa8 {
    
    public String nome;
    public int idade;
    
    void apresentar(){

        Scanner ll = new Scanner(System.in);

        System.out.println("Digite o Nome: ");
        this.nome = ll.nextLine();

        System.out.println("Digite a Idade: ");
        this.idade=ll.nextInt();

        System.out.println(this.nome + "  " + this.idade);
    }
}
