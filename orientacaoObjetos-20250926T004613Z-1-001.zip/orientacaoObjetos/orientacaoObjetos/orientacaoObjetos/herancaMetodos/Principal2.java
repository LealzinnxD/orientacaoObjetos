public class Principal2 {
    
    public static void main(String[] args) {
        

      Produto3 eduu = new Produto3();
      Aluno leal = new Aluno();
      Livro10 ler = new Livro10();

      ler.getDescricao();

      //leal.verificarAprovacao();

     //eduu.calculaTotal();

     // wood.calcularArea();
      
      //flavin.apresentar();

    }
}
