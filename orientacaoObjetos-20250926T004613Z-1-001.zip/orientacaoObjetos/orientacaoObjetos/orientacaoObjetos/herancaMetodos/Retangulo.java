import java.util.Scanner;

public class Retangulo {
    
    public int largura;
    public int altura;

     double  calcularArea(){
     
        Scanner jv = new Scanner(System.in);
        
        System.out.println("Informe a Largura: ");
        this.largura=jv.nextInt();
        
        System.out.println("Informe a Altura: ");
        this.altura=jv.nextInt();

        double area = (this.altura + this.largura)/2;

        System.out.println(area);

        return area;
   } 

}
