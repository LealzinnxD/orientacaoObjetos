import java.util.Scanner;

public class Livro {
    
    public String autor;
    public String titulo;

    String getDescricao(){

        Scanner jvl = new Scanner(System.in);

        System.out.println("Digite o Autor: ");
        this.autor=jvl.nextLine();

        System.out.println("Digite o Titulo: ");
        this.titulo=jvl.nextLine();

        

        return ();
    }
}
