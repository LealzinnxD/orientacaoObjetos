import java.util.Scanner;

public class Aluno {
    
    public String nome;
    public int n1;
    public int n2;
    public int n3;

    void verificarAprovacao(){
     
        Scanner msg = new Scanner(System.in);

        System.out.println("Digite o Nome: ");
        this.nome=msg.nextLine();

        System.out.println("Digite a Nota 1: ");
        this.n1=msg.nextInt();

        System.out.println("Digite a Nota 2: ");
        this.n2=msg.nextInt();

        System.out.println("Digite a Nota 3: ");
        this.n3=msg.nextInt();

        double  media = (n1+n2+n3)/3;

        if(media>=7){
        
            System.out.println("Está Aprovado: " + media);
        }else{
            System.out.println("Está Reprovado: " + media);
        }
    }
}
