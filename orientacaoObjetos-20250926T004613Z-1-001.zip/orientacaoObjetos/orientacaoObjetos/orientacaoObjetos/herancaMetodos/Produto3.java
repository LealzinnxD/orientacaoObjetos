import java.util.Scanner;

public class Produto3 {
    
    public String nome;
    public  int preco;
    public  int quantidade;

    double calculaTotal(){

     Scanner lil = new Scanner(System.in);

     System.out.println("Digite o Nome: ");
     this.nome=lil.nextLine();

     System.out.println("Digite o Preço: ");
     this.preco=lil.nextInt();

     System.out.println("Digite a Quantidade: ");
     this.quantidade=lil.nextInt();

     double valorTotal = (this.preco*this.quantidade);
     System.out.println(valorTotal);

     return valorTotal ;
    }
}
