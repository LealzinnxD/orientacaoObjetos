import java.util.Scanner;

public class Livro10 extends Produto12 {
  public String autor;
    public Float numeroPaginas;

      void lerDados(){  

        Scanner bmw = new Scanner(System.in);

    System.out.println("Qual o nome do Livro");
    this.nome = bmw.nextLine();

    System.out.println("Digite o preço do Livro R$");
    this.preco = bmw.nextFloat();

    System.out.println("O nome do autor");
    this.autor = bmw.nextLine();

    this.autor = bmw.nextLine();
    System.out.println("O número de paginas é");
    this.numeroPaginas = bmw.nextFloat();

    System.out.println("nome" + this.nome + " Preço" + this.preco + " Autor" + this.autor + " Numero de Paginas" + this.numeroPaginas);

      }

      

    }
    

