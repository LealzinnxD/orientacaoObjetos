import java.util.Scanner;

public class Cachorro extends Animal10 {
    void latir(){
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o nome do Cachorro: ");
        this.nome=jv.nextLine();

        System.out.println("Digite a Idade do Cachorro: ");
        this.idade=jv.nextInt();

        System.out.println("Nome do Cachorro:  " + this.nome + "  A Idade do Cachorro:  " + this.idade);
    }
    
}
