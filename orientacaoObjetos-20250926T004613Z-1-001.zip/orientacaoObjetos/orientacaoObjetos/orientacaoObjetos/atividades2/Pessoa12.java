public class Pessoa12 {
    public String nome;
    public int idade;
}
