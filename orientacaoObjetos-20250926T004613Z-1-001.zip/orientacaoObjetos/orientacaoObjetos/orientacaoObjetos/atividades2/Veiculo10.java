public class Veiculo10 {
    public String marca;
    public String modelo;
    public int portas;
    
}
