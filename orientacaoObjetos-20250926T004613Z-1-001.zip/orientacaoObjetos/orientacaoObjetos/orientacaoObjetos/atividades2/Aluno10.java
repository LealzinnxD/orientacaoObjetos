import java.util.Scanner;

public class Aluno10 extends Pessoa15  {
 

    void lerrdados(){
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do Aluno: ");
        this.nome = jv.nextLine();

        System.out.println("Digite o Curso do Aluno: ");
        this.curso= jv.nextLine();

        System.out.println("Digite a Idade do Aluno:  ");
        this.idade = jv.nextInt();

        System.out.println("Digite a Matricula do Aluno: ");
        this.matricula=jv.nextInt();

        System.out.println("Nome: " + this.nome + " Curso: " + this.curso + " A idade: " + this.idade + " A matricula: " + this.matricula);
        
    }
    
}
