import java.util.Scanner;

public class Gato extends Animal11 {
    void gatinho(){
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o nome do Gato: ");
        this.nome=jv.nextLine();

        System.out.println("Digite a cor dos Pelos do Gato: ");
        this.pelo=jv.nextLine();

        System.out.println("Digite a Idade do Gato: ");
        this.idade = jv.nextInt();

        System.out.println("O nome do Pet:  " + this.nome + "  A cor dos Pelos do Pet:  " + this.pelo + "  A idade do Pet:  " + this.idade);

        
    }
}
