public class Animal11 {
    public String nome;
    public String pelo;
    public int idade;
}
