public class Principall {
    public static void main(String[] args) {
        Aluno10 jvl = new Aluno10();
        Gerente enz = new Gerente();
        Cachorro wd = new Cachorro();
        Carro10 manu = new Carro10();
        Gato flavin = new Gato();
        Empregado edu = new Empregado();
        Livro10 duduzin = new Livro10();

        duduzin.lerDados();
        //edu.lerSalario();
        //flavin.gatinho();
        //manu.carrao();
        //wd.latir();
        //enz.salarioBruto();
        //jvl.lerrdados();
    }
}
