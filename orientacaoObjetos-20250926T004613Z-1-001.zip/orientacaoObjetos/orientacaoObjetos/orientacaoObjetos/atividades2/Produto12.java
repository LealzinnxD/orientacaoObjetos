public class Produto12 {

    public String nome;
    public Float preco;
     
    
}
