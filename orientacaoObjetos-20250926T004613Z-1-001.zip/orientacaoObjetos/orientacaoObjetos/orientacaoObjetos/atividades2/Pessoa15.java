public class Pessoa15  {
    public String nome;
    public String curso;
    public int idade;
    public int matricula;

}
