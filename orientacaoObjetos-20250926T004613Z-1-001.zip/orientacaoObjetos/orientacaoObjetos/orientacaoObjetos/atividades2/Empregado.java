import java.util.Scanner;
public class Empregado extends Pessoa12 {
    


    public Float salario;

    void lerSalario(){
 Scanner bmw = new Scanner(System.in);

 
   System.out.println("Qual o nome");
   this.nome = bmw.nextLine();

   System.out.println("Digite a idade");
   this.idade = bmw.nextInt();

   System.out.println("Ler Salario");
   this.salario = bmw.nextFloat();

   double salaraioFinal = (this.salario*12);
   System.out.println("nome: " + this.nome + "  idade:  " + this.idade + "  salario:  " + salaraioFinal);

    }
   
}

