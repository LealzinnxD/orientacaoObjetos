import java.util.Scanner;

public class Carro10 extends Veiculo10 {
    void carrao(){
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite a Marca do veiculo: ");
        this.marca=jv.nextLine();

        System.out.println("Digite o Modelo do Veiculo: ");
        this.modelo=jv.nextLine();

        System.out.println("Quantidade de Portas do Veiculo: ");
        this.portas=jv.nextInt();

        System.out.println("Marca:  " + this.marca + "  Modelo: " + this.modelo + "  Quantidades de Portas: " + this.portas);

    }
}
