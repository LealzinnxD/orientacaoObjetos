import java.util.Scanner;

public class Gerente extends Funcionario10 {
    void salarioBruto(){
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do Funcionario: ");
        this.nome=jv.nextLine();

        System.out.println("Digite o Setor do Funcionario: ");
        this.setor=jv.nextLine();

        System.out.println("Digite o Salario do Funcionario: ");
        this.salario=jv.nextDouble();

        Double salariofim= (this.salario*0.10)+this.salario;

        System.out.println("Nome do Funcionario:  " + this.nome + "  Setor do Funcionario:  " + this.setor + "  Salario:  " + salariofim);
    }
    }
    

