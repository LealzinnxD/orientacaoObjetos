public class Animal10 {
    public String nome;
    public int idade;
    
}
