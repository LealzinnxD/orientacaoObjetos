public class Funcionario10 {
    
    public String nome;
    public String  setor;
    public Double salario;
    
}
