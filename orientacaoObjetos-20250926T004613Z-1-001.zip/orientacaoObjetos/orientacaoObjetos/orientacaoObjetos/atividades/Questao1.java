import java.util.Scanner;

public class Questao1 extends Estudante {
    
    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);

        Estudante pedri = new Estudante();

         pedri.estudar();


    }
}
