import java.util.Scanner;

public class Produto2 {
public  String nome;
public  String categoria;
public  double preco;
public  int estoque;

void sistema(){

Scanner jv = new Scanner(System.in);

System.out.print("Nome do produto: ");
this.nome = jv.nextLine(); 
System.out.print("Categoria: ");
this.categoria = jv.nextLine();

System.out.print("Preço: ");
this.preco = jv.nextDouble();
System.out.print("Estoque: ");
this.estoque = jv.nextInt();
System.out.print("Quantidade para adicionar ao estoque: ");
int qtd = jv.nextInt();
this.estoque += qtd;
System.out.println("\nProduto: " + this.nome);
System.out.println("Categoria: " + this.categoria);
System.out.println("Preço: R$" + this.preco);
System.out.println("Estoque atualizado: " + this.estoque);
}
}
