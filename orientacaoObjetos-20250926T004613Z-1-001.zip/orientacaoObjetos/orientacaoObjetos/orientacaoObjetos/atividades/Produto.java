import java.util.Scanner;

public class Produto {
    
    public String nome;
    public Double preco;

    void produtos(){
    Scanner jv = new Scanner(System.in);

    System.out.println("Nome do produto: ");
    this.nome=jv.nextLine();

    System.out.println("Preço do produto: ");
    this.preco=jv.nextDouble();

    if (this.preco > 100) {
        this.preco = this.preco * 0.9;
        }
        System.out.println("Preço final: R$" + this.preco);

    }
}
