import java.util.Scanner;

public class Estudante {
    
    public String nome;
    public String matricula;
    public String curso;


    void estudar(){

Scanner jv = new Scanner(System.in);

        System.out.println("Nome: ");
        this.nome=jv.nextLine();

        System.out.println("Matrícula: ");
        this.matricula=jv.nextLine();

        System.out.println("Curso: ");
        this.curso=jv.nextLine();

        System.out.println("Nome: " + this.nome);
        System.out.println("Matrícula: " + this.matricula);
        System.out.println("Curso: " + this.curso);
    }



}
