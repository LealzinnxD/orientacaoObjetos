import java.util.Scanner;

public class Usuario {
    
    public String nome;
    public String login;
    public String senha;

    void loginEsenha(){

        Scanner jv = new Scanner(System.in);
        this.nome = "João";
        this.login = "joao";
        this.senha = "1224";

        System.out.println("Login: ");
        this.login = jv.nextLine();

        System.out.println("Senha: ");
        this.senha = jv.nextLine();

        if (login.equals(this.login) && senha.equals(this.senha)) {
            System.out.println("Login correto ");
            } else {
            System.out.println("Login ou senha incorretos.");
            }
    }
}
