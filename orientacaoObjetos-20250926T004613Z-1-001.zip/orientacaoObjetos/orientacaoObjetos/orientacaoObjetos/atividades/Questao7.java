import java.util.Scanner;

public class Questao7 {
    
    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);
        Produto2 lewa = new Produto2();

        lewa.sistema();
    }
}
