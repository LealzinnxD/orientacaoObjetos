import java.util.Scanner;

public class Questao6 {
    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);
        Vendedor yamal = new Vendedor();

        yamal.totalvendas();
    }
}
