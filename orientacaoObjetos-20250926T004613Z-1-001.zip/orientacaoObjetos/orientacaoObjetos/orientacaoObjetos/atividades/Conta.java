import java.util.Scanner;

public class Conta {
    
    public String titular1;
    public String titular2;
    public Double saldo1;
    public Double saldo2;

    void valores(){
        Scanner jv = new Scanner(System.in);
        this.titular1 = "Ana";
        this.saldo1 = 500.0;
        this.titular2 = "Pedro";
        this.saldo2 = 300.0;
        System.out.print("Valor da transferência de Ana para Pedro: ");
        Double valor = jv.nextDouble();

        if (this.saldo1 >= valor) {
        this.saldo1 -= valor;
        this.saldo2 += valor;
        System.out.println("Transferência feita com sucesso.");
        } else {
        System.out.println("Saldo insuficiente.");
        }
        System.out.println("Saldo Ana: R$" + this.saldo1);
        System.out.println("Saldo Pedro: R$" + this.saldo2);


    }
}
