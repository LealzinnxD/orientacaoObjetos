import java.util.Scanner;

public class Veiculo {
    public String modelo;

        void lerDado(){

        Scanner jv = new Scanner(System.in);
        System.out.println("Digite o Modelo: ");
        modelo=jv.nextLine();
        System.out.println("Carro: " + modelo);
        modelo=jv.nextLine();
        System.out.println("Moto: " + modelo);
        modelo=jv.nextLine();

        
    }
}
