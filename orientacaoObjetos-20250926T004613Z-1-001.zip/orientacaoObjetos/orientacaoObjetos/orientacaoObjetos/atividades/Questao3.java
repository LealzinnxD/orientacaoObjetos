import java.util.Scanner;

public class Questao3 {
    public static void main(String[] args) {
        
        Scanner jv = new Scanner(System.in);
        Produto12 cubarsi = new Produto12();

        cubarsi.produtos();
    }
}
