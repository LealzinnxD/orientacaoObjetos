import java.util.Scanner;

public class Vendedor {
    
    public String nome;
    public Double vendas;
    public Double comissao;

    void totalvendas(){
        Scanner jv = new Scanner(System.in);

        System.out.print("Nome do vendedor: ");
        this.nome = jv.nextLine();
        System.out.print("Total de vendas: ");
        this.vendas = jv.nextDouble();
        this.comissao = this.vendas * 0.1;
        System.out.println("Comissão: R$" + this.comissao);
    }
}
