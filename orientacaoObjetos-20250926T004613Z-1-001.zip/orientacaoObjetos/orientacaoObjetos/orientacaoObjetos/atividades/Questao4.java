import java.util.Scanner;

public class Questao4 {
    
    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);
        Conta olmo = new Conta();

        olmo.valores();

    }
}
