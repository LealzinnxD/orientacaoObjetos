import java.util.Scanner;

public class Questao2 extends Usuario {
    
    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);
        Usuario gavi = new Usuario();

        gavi.loginEsenha();

    }
}
