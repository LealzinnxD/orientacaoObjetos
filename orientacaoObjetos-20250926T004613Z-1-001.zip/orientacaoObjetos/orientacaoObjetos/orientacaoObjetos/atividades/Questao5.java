import java.util.Scanner;

public class Questao5 {
    public static void main(String[] args) {

        Scanner jv = new Scanner(System.in);

        Veiculo raphinha = new Veiculo();

        raphinha.lerDado();
        
    }
    
    
}
