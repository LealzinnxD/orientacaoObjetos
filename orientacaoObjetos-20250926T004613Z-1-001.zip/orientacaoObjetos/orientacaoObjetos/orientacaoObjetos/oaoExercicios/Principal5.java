public class Principal5 {
    
    public static void main(String[] args) {
        
        Funcionario leal = new Funcionario();
        Produto5 ll = new Produto5();
        Livro2 manu = new Livro2();
        Aluno flavin = new Aluno();



       // flavin.leerDados();
        // manu.lerdadoss();
        //leal.lerDados();
        //ll.cadastrar();

    }
}
