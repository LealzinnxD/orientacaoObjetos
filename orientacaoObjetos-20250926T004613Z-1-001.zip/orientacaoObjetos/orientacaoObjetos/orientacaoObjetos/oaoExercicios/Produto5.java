import java.util.Scanner;
public class Produto5 {

    //exercicío 1.

    public String nome;
    public int preco;

    void cadastrar(){

    Scanner jv = new Scanner(System.in);

    System.out.println("Digite o nome do produto: ");
    this.nome = jv.nextLine();

    System.out.println("Digite o preço:  ");
    this.preco=jv.nextInt();

    System.out.println("Produto cadastrado: ");
    System.out.println("Nome: " + nome);
    System.out.println("Preço: R$ " + preco);

    }
}
