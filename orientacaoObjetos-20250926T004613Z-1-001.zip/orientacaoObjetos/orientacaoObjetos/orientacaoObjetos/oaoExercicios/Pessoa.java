import java.util.Scanner;

public class Pessoa {
    
    public String nome;

    void lerNome(){

        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome: ");
        this.nome=jv.nextLine();

        
    }
}
