
    
    import java.util.Scanner;

public class Calculadora {

    //Exercicío 5
    
    
    public double somar(double a, double b) {
        return a + b;
    }

    
    public double subtrair(double a, double b) {
        return a - b;
    }

    public static void main(String[] args) {
        Scanner jv = new Scanner(System.in);
        Calculadora calc = new Calculadora();

        
        System.out.print("Digite o primeiro número: ");
        double n1 = jv.nextDouble();

        System.out.print("Digite o segundo número: ");
        double n2 = jv.nextDouble();

        
        System.out.print("Digite a operação (+ ou -): ");
        char operacao = jv.next().charAt(0);

        double resultado;

        
        if (operacao == '+') {
            resultado = calc.somar(n1, n2);
            System.out.println("Resultado: " + resultado);
        } else if (operacao == '-') {
            resultado = calc.subtrair(n1, n2);
            System.out.println("Resultado: " + resultado);
        } else {
            System.out.println("Operação inválida.");
        }

        jv.close();
    }
}

