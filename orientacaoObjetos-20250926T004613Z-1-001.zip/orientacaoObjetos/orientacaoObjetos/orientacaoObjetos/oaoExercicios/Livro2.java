import java.util.Scanner;

public class Livro2 {
    
    //Exercicío 3
    
    public  String titulo;
    public String autor;

    void lerdadoss(){

        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Título do Livro: ");
        this.titulo=jv.nextLine();

        System.out.println("Digite o Nome do Autor: ");
        this.autor=jv.nextLine();

        System.out.println("Título: " + this.titulo);
        System.out.println("Autor: " + this.autor);
    }
}
