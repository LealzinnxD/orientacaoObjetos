import java.util.Scanner;

public class Funcionario {
    
    //Exercicío 2

    public String nome;
    public float salario;
    

    void lerDados(){

        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o nome: ");
        this.nome=jv.nextLine();

        System.out.println("Digite o Salário: ");
        this.salario=jv.nextFloat();

        double bonus = (salario*1.10) + salario;
        System.out.println("O salario com o bonus é: " + bonus);

        
        

      
    }

   

        


    
}    
