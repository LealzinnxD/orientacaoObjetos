import java.util.Scanner;

public class Aluno extends Pessoa9 {
    
    //Exercicío 4
    
    public String curso;

    void leerDados(){
        
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Curso: ");
        this.curso=jv.nextLine();


        System.out.println("Nome:" + this.nome);
        System.out.println("Curso:" + this.curso);


    }

}
