public class ClasseFilho extends ClasseMae {
    
    public String escolaridade;

}
