public class Sistema1 {
    
    public String nome;
    public String cpf;
    
}
