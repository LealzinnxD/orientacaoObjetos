public class Pessoa {
    String nome = "  Leal  ";
    int idade = 20;
    String genero = " Masculino  ";
    
}
