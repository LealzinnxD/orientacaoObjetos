public class Carro {
    
    String nome = "HB20";
    String marca = "Hyundai";
    String combustivel = "Flex";
    int ano = 2020;
    Double km = 20.655;
}
