public class Sistema {
    
    public String nome;
    public String cpf;





    
}
