public class ClasseFilha extends ClasseMae {
    
    public String escolaridade;
}
