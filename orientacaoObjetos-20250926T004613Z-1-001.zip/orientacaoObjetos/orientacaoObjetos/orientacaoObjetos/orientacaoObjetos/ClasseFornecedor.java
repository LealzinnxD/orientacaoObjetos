public class ClasseFornecedor  {
    
    public int estoque;

}
