public class Classe1 {
    
    public float n1;
    public float n2;
    public float media;

    
}
