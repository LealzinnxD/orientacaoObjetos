public class Classe3 {
    
    public int opcao;

}
