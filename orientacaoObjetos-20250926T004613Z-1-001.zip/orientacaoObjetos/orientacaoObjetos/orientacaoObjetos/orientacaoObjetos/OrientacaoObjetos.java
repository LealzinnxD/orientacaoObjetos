public class OrientacaoObjetos {
    public static void main(String[] args) {
        
        Cliente Leal = new Cliente();
        System.out.println(Leal.nome);
    }
}
