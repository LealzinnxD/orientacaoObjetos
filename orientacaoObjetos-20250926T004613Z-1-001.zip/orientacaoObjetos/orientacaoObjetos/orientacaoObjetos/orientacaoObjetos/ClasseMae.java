public class ClasseMae {
    public String nome;
    public int idade;
    public int ano;
    public String cpf;
    public int qtdFilhos;
}
