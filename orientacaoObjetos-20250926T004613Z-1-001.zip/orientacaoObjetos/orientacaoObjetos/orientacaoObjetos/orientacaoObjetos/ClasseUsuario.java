public class ClasseUsuario extends Sistema1 {
    
    public String senha;

}
