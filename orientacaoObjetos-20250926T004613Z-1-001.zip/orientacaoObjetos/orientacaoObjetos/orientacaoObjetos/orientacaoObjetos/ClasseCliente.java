public class ClasseCliente  extends Sistema1{
    
    public String razaoSocial;

}
