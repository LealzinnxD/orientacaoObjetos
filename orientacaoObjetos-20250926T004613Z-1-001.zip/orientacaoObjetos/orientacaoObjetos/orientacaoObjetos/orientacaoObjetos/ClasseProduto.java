public class ClasseProduto extends Sistema1 {
    
    public float preco;
}
