public class Pessoa9 {
    public String nome;
    public String email;
}
