import java.util.Scanner;

public class ScannerFilme extends Filme implements EntradaDados {
    
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Titulo do Filme: ");
        this.titulo=jv.nextLine();

        System.out.println("Digite o Gênero do Filme: ");
        this.genero=jv.nextLine();

        System.out.println("o Titulo do Filme: " + this.titulo + " Gênero do Filme: " + this.genero );
    }
}
