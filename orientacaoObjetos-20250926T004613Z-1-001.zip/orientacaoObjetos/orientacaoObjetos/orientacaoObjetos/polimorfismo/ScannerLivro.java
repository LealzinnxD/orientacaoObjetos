import java.util.Scanner;

public class ScannerLivro extends Livro9 implements EntradaDados {
    
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Autor de um Livro: ");
        this.autor=jv.nextLine();

        System.out.println("Digite um Titulo de um Livro: ");
        this.titulo=jv.nextLine();

        System.out.println("Autor do Livro: " + this.autor + " Titulo de um Livro: " + this.titulo);
    }
}
