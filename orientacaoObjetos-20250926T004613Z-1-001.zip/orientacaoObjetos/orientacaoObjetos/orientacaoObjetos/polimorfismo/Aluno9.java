public class Aluno9 {
    
    public String nome;
    public int nota;
    
}
