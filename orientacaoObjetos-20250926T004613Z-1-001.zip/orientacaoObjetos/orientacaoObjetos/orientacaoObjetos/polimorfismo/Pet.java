public class Pet {
    public String nome;
    public String raca;
    
}
