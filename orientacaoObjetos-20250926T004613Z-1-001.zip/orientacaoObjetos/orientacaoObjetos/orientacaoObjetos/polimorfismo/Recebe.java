import java.util.Scanner;

public class Recebe  extends Pessoa9 implements EntradaDados {
    
    public void lerDados(){
        Scanner jv = new Scanner(System.in);
        System.out.println("Digite seu Nome: ");
        this.nome = jv.nextLine();

        System.out.println("Digite seu email: ");
        this.email=jv.nextLine();

        System.out.println("Nome: " + this.nome +  " Email: " + this.email);
    }
    
}
