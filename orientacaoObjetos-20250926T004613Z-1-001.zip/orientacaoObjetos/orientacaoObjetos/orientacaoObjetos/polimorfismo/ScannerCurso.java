import java.util.Scanner;

public class ScannerCurso extends Curso5 implements EntradaDados {
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do seu Curso: ");
        this.nome=jv.nextLine();

        System.out.println("Digite a Duração do Curso: ");
        this.duracao=jv.nextFloat();

        System.out.println(" o Nome do seu Curso É: " + this.nome + " a Duração do Curso É: " + this.duracao);
    }
}
