public class Filme {
    public String titulo;
    public String genero;

    
}
