import java.util.Scanner;

public class ScannerPet extends Pet implements EntradaDados {
    @Override
    public void lerDados() {
        Scanner jv =new Scanner(System.in);

        System.out.println("Digite o Nome do Seu Pet: ");
        this.nome=jv.nextLine();

        System.out.println("Digite a Raça do Seu Pet: ");
        this.raca=jv.nextLine();

        System.out.println("o Nome do Seu Pet É: " + this.nome + " A raça do Seu Pet É: " + this.raca);
    }
}
