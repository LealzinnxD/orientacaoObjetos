import java.util.Scanner;

public class ScannerCidade extends Cidade implements EntradaDados{
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Cidade Aonde você mora: ");
        this.cidade=jv.nextLine();

        System.out.println("Estado Aonde você mora: ");
        this.estado = jv.nextLine();

        System.out.println("Cidade Aonde você mora: " + this.cidade + " Estado Aonde você mora: " + this.estado);
    }
}
