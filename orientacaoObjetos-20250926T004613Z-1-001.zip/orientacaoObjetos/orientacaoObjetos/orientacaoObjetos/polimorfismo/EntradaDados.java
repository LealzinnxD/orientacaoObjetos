public interface EntradaDados {

    void lerDados();
} 
    

