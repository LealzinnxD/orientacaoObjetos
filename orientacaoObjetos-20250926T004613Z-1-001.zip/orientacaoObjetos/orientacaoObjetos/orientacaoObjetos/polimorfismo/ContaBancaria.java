public class ContaBancaria {
    public String titularConta;
    public Float saldo;
    
}
