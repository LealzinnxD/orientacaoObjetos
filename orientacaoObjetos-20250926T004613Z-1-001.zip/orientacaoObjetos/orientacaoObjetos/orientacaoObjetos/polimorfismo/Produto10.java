public class Produto10 {
    
    public String nome;
    public float preco;
    
}
