public class Veiculo3 {
    public String marca;
    public String ano;
}
