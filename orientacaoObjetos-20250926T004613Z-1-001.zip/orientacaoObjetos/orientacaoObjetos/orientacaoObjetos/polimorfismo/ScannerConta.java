import java.util.Scanner;

public class ScannerConta extends ContaBancaria implements EntradaDados {
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do Titular da Conta: ");
        this.titularConta=jv.nextLine();

        System.out.println("Digite o Saldo Bancario: ");
        this.saldo=jv.nextFloat();

        System.out.println("Nome do Titular da Conta: " + this.titularConta + " Saldo Bancario:" + this.saldo);

    }
}
