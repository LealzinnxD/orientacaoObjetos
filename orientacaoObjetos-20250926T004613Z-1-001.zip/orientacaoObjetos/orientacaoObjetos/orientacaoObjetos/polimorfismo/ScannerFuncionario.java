import java.util.Scanner;

public class ScannerFuncionario extends Funcionario3 implements EntradaDados{
    
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do Funcionario: ");
        this.nome=jv.nextLine();

        System.out.println("Digite o Cargo do Funcionario: ");
        this.cargo=jv.nextLine();

        System.out.println("Digite o Sálario do Funcionario: ");
        this.salario=jv.nextFloat();

        System.out.println(this.nome + "  " + this.cargo + "  " + this.salario);
    }
}
