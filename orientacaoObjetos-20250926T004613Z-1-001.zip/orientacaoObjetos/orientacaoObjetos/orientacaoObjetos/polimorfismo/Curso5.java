public class Curso5 {
    public String nome;
    public Float duracao;
    
}
