public class Cidade {
    public String cidade;
    public String estado;
    
}
