import java.util.Scanner;

public class ScannerVeiculo extends Veiculo3 implements EntradaDados {
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite a Marca do Carro: ");
        this.marca=jv.nextLine();

        System.out.println("Digite o Ano do Carro: ");
        this.ano=jv.nextLine();

        System.out.println("Marca: " + this.marca + " Ano: " + this.ano);
    }
    
}
