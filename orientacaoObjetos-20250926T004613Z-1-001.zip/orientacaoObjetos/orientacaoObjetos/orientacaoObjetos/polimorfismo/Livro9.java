public class Livro9 {
    
    public String autor;
    public String titulo;
}
