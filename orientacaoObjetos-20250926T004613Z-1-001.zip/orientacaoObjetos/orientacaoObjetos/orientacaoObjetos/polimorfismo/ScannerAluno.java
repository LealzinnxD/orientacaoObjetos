import java.util.Scanner;

public class ScannerAluno extends Aluno9 implements EntradaDados {
    
    @Override
    public void lerDados() {
        Scanner jv = new Scanner(System.in);

        System.out.println("Digite o Nome do Aluno: ");
        this.nome=jv.nextLine();

        System.out.println("Digite a Nota do Aluno: ");
        this.nota=jv.nextInt();

        if(this.nota>= 6){
            System.out.println("Aluno Aprovado!! ");
        }else{
            System.out.println("Aluno Reprovado!! ");
        }
    }
}
