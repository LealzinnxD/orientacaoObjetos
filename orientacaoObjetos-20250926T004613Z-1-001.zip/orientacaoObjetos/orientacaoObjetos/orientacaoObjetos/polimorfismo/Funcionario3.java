public class Funcionario3 {
    public String nome;
    public String cargo;
    public Float salario;
    
}
