import java.util.Scanner;

public class PrincipalSistema {
    public static void main(String[] args) {
        Recebe barela = new Recebe();
        ScannerProduto thuram = new ScannerProduto();
        ScannerAluno bastoni = new ScannerAluno();
        ScannerVeiculo dimarco = new ScannerVeiculo();
        ScannerLivro sommer = new ScannerLivro();
        ScannerFuncionario lautaro = new ScannerFuncionario();
        ScannerCidade fratessi = new ScannerCidade();
        ScannerConta dumfries = new ScannerConta();
        ScannerFilme acerbi = new ScannerFilme();
        ScannerPet pavard = new ScannerPet();
        ScannerCurso sla = new ScannerCurso();

        sla.lerDados();
        //pavard.lerDados();
        //acerbi.lerDados();
        //dumfries.lerDados();
        //fratessi.lerDados();
        //lautaro.lerDados();
        //sommer.lerDados();
        //dimarco.lerDados();
        //bastoni.lerDados();
        //thuram.lerDados();
        //barela.lerDados();

        

    }
}
